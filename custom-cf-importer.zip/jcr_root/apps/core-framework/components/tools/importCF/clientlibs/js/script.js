$(document).ready(
	function () {
		var form = $('form.importCF'),
			importActionURL = form.attr('action');

		form.find('.file-upload input').on('change', function () {
			var file = this && this.files && this.files.length > 0 && this.files[0];
			var isValidFile = validateInputFile(file);

			if (isValidFile) {
				form.find('.file-name').text(file.name);
			}
			form.find('.file-upload').toggleClass('is-file', isValidFile);
		});

		form.find('#uploadFileBtn').on('click', function (e) {
			handleFormSubmit(e, form, `${importActionURL}.import-cf.json`, 'post');
		});

		form.find('#cfRootPath').on('change', function (e) {
			var exportBtn = form.find('#exportDataBtn');
			if (e.currentTarget.value === '') {
				exportBtn.attr('disabled', 'disabled');
			} else {
				exportBtn.removeAttr('disabled');
			}
		});

		form.find('#exportDataBtn').on('click', function (e) {
			e.preventDefault();
			if (e.currentTarget.hasAttribute('disabled')) {
				return;
			}
			if (form.find('#cfRootPath').val() === '') {
				alert('Please provide root path!');
				return;
			}
			if (form.find('#cfModel').val() === '') {
				alert('Please select content fragment model!');
				return;
			}
			const anchor = document.createElement('a');
			anchor.href = `${importActionURL}.export-cf-data.json?cfModel=${form.find('#cfModel').val()}&cfRootPath=${form.find('#cfRootPath').val()}`;
			anchor.setAttribute('target', '_blank');
			anchor.setAttribute('id', 'exportExcel');
			document.body.append(anchor);
			document.body.querySelector('#exportExcel').click();
			document.body.querySelector('#exportExcel').remove();
			form[0].reset();
			e.currentTarget.setAttribute('disabled', 'disabled');
		});

		// form.find('[name="cfModel"]').on('change', function () {
		// 	var downloadLink = `${importActionURL}.export-cf.json?cfModel=${$(this).val()}`;
		// 	form.find('.downloadcf-wrapper').removeAttr('hidden');
		// 	form.find('#downloadCF').attr('href', downloadLink);
		// });
		form.find('[name="cfModel"]').on('change', function () {
			const model = $(this).val();                 // full CFM path
			if (model) {
				// build the new URL that calls your XLSX servlet
				const downloadLink =
					  `${importActionURL}.export-cf.xlsx?cfModel=${encodeURIComponent(model)}`;
		
				form.find('#downloadCF')
					.attr('href', downloadLink)          // point to servlet
					.attr('download',                    // nice filename in Save As…
						   `${model.split('/').pop()}-sample.xlsx`);
		
				form.find('.downloadcf-wrapper').prop('hidden', false);
			} else {
				// no model selected ➜ hide link + clean attrs
				form.find('.downloadcf-wrapper').prop('hidden', true);
				form.find('#downloadCF').removeAttr('href download');
			}
		});
		

		function handleFormSubmit(event, form, actionURL, method) {
			event.preventDefault();
		  
			// Validate required fields if needed
			if (form.find('#cfRootPath').val() === '') {
			  alert('Please provide required fields!');
			  return;
			}
		  
			var uploadBtn = form.find('#uploadFileBtn');
			var exportBtn = form.find('#exportDataBtn');
		  
			// Disable buttons to prevent multiple submissions
			uploadBtn.attr('disabled', 'disabled');
			exportBtn.attr('disabled', 'disabled');
		  
			// Display the importing message
			form.find('.form-message').text('Importing, please wait...this can take a few minutes');
		  
			var formData = new FormData(form[0]);
			var xhr = new XMLHttpRequest();
			xhr.open(method, actionURL, true);
			
			// Remove any manually set Content-Type header, so the browser sets multipart/form-data correctly.
			// xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded'); // Remove this line if present.
			
			xhr.onload = function () {
			  // Re-enable buttons after processing
			  uploadBtn.removeAttr("disabled");
			  exportBtn.removeAttr("disabled");
		  
			  var response = JSON.parse(xhr.responseText);
			  if (xhr.status === 200) {
				// Display a success message; you might show additional details from the response.
				form.find('.form-message').text("Import successful! ");
				form[0].reset();
			  } else {
				// Display an error message if the request failed.
				form.find('.form-message').text("Error: " + response.error);
			  }
			}
			
			xhr.send(formData);
		}		  

		function validateInputFile(file) {
			var uploadBtn = form.find('#uploadFileBtn');
			// Check for XLSX file type
			var isInvalid = file.type !== "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
			uploadBtn.removeAttr("disabled");
		
			if (isInvalid) {
				alert("Wrong file type - only XLSX files are accepted");
				form.find("#fileToUpload").val(null);
				uploadBtn.attr('disabled', 'disabled');
				return false;
			}
			return true;
		}		
	}
);
